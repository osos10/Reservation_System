package elhakki.ossama.systeme_de_reservation;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SystemeDeReservationApplicationTests {

    @Test
    void contextLoads() {
    }

}
