package elhakki.ossama.systeme_de_reservation.Enums;

public enum Role {
    ADMIN,
    JURY,
    USER
}
