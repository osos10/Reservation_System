package elhakki.ossama.systeme_de_reservation.Enums;

public enum ReservationStatus {
    Confirmed,
    Cancelled
}
